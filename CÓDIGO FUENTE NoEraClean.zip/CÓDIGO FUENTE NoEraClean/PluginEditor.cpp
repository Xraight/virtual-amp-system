#include "BinaryData.h"
#include "PluginProcessor.h"
#include "PluginEditor.h"

MESABOOGIEINGSOFTAMPAudioProcessorEditor::MESABOOGIEINGSOFTAMPAudioProcessorEditor(MESABOOGIEINGSOFTAMPAudioProcessor& p)
    : AudioProcessorEditor(&p), audioProcessor(p)
{
    juce::Colour mesaOrange = juce::Colour(0xFFFF9900);

    // --- PRESETS Y TUNER ---
    tunerBtn.setButtonText("TUNER");
    tunerBtn.setClickingTogglesState(true);
    tunerBtn.setColour(juce::TextButton::buttonOnColourId, juce::Colours::red.withAlpha(0.6f));
    
    tunerBtn.onClick = [this]
        {
            updateVisibility();
            resized();
            repaint();
        };
    addAndMakeVisible(tunerBtn);

    for (auto* btn : { &odFootswitch, &choFootswitch, &delFootswitch })
    {
        btn->setClickingTogglesState(true);
        btn->setLookAndFeel(&footswitchLF);
        btn->setColour(juce::TextButton::buttonColourId, juce::Colour(0xFF2A2A2A));
        btn->setColour(juce::TextButton::buttonOnColourId, juce::Colour(0xFF111111));
        btn->setColour(juce::TextButton::textColourOffId, juce::Colours::transparentBlack);
        btn->setColour(juce::TextButton::textColourOnId, juce::Colours::transparentBlack);
        addAndMakeVisible(btn);
    }

    // Lógica de Footswitches para apagar pedales (Forzar parámetros a 0)
 
    presetMenu.setTextWhenNothingSelected("Seleccionar Preset...");

    // --- AQUÍ Llenamos el menú con la base de datos real ---
    auto presetsExistentes = audioProcessor.database.getAllPresets();
    for (auto& p : presetsExistentes) {
        presetMenu.addItem(p.nombre, p.id);
    }

    // --- AQUÍ programamos qué pasa al dar click ---
    presetMenu.onChange = [this] {
        int id = presetMenu.getSelectedId();
        if (id > 0) {
            // Llamamos a la función del processor que ya programamos antes
            audioProcessor.loadPresetFromDB(id);
            DBG("Cargando preset ID: " << id);
        }
        };

    addAndMakeVisible(presetMenu);

    savePresetBtn.setButtonText("SAVE");

    savePresetBtn.onClick = [this] {
        auto* dialog = new juce::AlertWindow(
            "Guardar Preset", "Nombre del preset:",
            juce::MessageBoxIconType::NoIcon);

        dialog->addTextEditor("nombre", "Mi Preset");
        dialog->addButton("Guardar", 1);
        dialog->addButton("Cancelar", 0);

        dialog->enterModalState(true, juce::ModalCallbackFunction::create(
            [this, dialog](int result) {
                if (result == 1)
                {
                    juce::String name = dialog->getTextEditorContents("nombre");
                    if (name.isNotEmpty())
                    {
                        auto& apvts = audioProcessor.apvts;

                        PresetDatabase::Preset preset;
                        preset.nombre = name;
                        preset.gain = apvts.getRawParameterValue("GAIN")->load();
                        preset.bass = apvts.getRawParameterValue("BASS")->load();
                        preset.mid = apvts.getRawParameterValue("MID")->load();
                        preset.treble = apvts.getRawParameterValue("TREBLE")->load();
                        preset.presence = apvts.getRawParameterValue("PRESENCE")->load();
                        preset.master = apvts.getRawParameterValue("MASTER")->load();
                        preset.input = apvts.getRawParameterValue("INPUT")->load();
                        preset.output = apvts.getRawParameterValue("OUTPUT")->load();
                        preset.lowcut = apvts.getRawParameterValue("LOWCUT")->load();
                        preset.highcut = apvts.getRawParameterValue("HIGHCUT")->load();
                        preset.odDrive = apvts.getRawParameterValue("OD_DRIVE")->load();
                        preset.odTone = apvts.getRawParameterValue("OD_TONE")->load();
                        preset.odLevel = apvts.getRawParameterValue("OD_LEVEL")->load();
                        preset.choRate = apvts.getRawParameterValue("CHO_RATE")->load();
                        preset.choDepth = apvts.getRawParameterValue("CHO_DEPTH")->load();
                        preset.choLevel = apvts.getRawParameterValue("CHO_LEVEL")->load();
                        preset.delTime = apvts.getRawParameterValue("DEL_TIME")->load();
                        preset.delFb = apvts.getRawParameterValue("DEL_FB")->load();
                        preset.delMix = apvts.getRawParameterValue("DEL_MIX")->load();
                        preset.eq1 = apvts.getRawParameterValue("EQ1")->load();
                        preset.eq2 = apvts.getRawParameterValue("EQ2")->load();
                        preset.eq3 = apvts.getRawParameterValue("EQ3")->load();
                        preset.eq4 = apvts.getRawParameterValue("EQ4")->load();
                        preset.eq5 = apvts.getRawParameterValue("EQ5")->load();
                        preset.eq6 = apvts.getRawParameterValue("EQ6")->load();
                        preset.irGain = apvts.getRawParameterValue("IR_GAIN")->load();
                        audioProcessor.database.savePreset(preset);

                        juce::Timer::callAfterDelay(100, [this]() {
                            presetMenu.clear();
                            auto todosLosPresets = audioProcessor.database.getAllPresets();
                            for (auto& pr : todosLosPresets)
                                presetMenu.addItem(pr.nombre, pr.id);
                            if (!todosLosPresets.empty())
                                presetMenu.setSelectedId(todosLosPresets.front().id,
                                    juce::dontSendNotification);
                            repaint();
                            });
                    }
                }
                delete dialog;
            }), true);
        };

    addAndMakeVisible(savePresetBtn);
    addAndMakeVisible(deletePresetBtn);
    addAndMakeVisible(updatePresetBtn);

    deletePresetBtn.onClick = [this] {
        int id = presetMenu.getSelectedId();
        if (id == 1) // ID 1 es el default, no se borra
        {
            juce::AlertWindow::showMessageBoxAsync(
                juce::MessageBoxIconType::WarningIcon,
                "Aviso",
                "El preset Clean Default no se puede borrar.");
            return;
        }
        if (id > 0) {
            audioProcessor.database.deletePreset(id);
            presetMenu.clear();
            for (auto& pr : audioProcessor.database.getAllPresets())
                presetMenu.addItem(pr.nombre, pr.id);
            repaint();
        }
        };

    updatePresetBtn.onClick = [this] {
        int id = presetMenu.getSelectedId();
        if (id > 0) {
            auto& apvts = audioProcessor.apvts;
            PresetDatabase::Preset preset;
            preset.id = id;
            preset.nombre = presetMenu.getText();
            preset.gain = apvts.getRawParameterValue("GAIN")->load();
            preset.bass = apvts.getRawParameterValue("BASS")->load();
            preset.mid = apvts.getRawParameterValue("MID")->load();
            preset.treble = apvts.getRawParameterValue("TREBLE")->load();
            preset.presence = apvts.getRawParameterValue("PRESENCE")->load();
            preset.master = apvts.getRawParameterValue("MASTER")->load();
            preset.input = apvts.getRawParameterValue("INPUT")->load();
            preset.output = apvts.getRawParameterValue("OUTPUT")->load();
            preset.lowcut = apvts.getRawParameterValue("LOWCUT")->load();
            preset.highcut = apvts.getRawParameterValue("HIGHCUT")->load();
            preset.odDrive = apvts.getRawParameterValue("OD_DRIVE")->load();
            preset.odTone = apvts.getRawParameterValue("OD_TONE")->load();
            preset.odLevel = apvts.getRawParameterValue("OD_LEVEL")->load();
            preset.choRate = apvts.getRawParameterValue("CHO_RATE")->load();
            preset.choDepth = apvts.getRawParameterValue("CHO_DEPTH")->load();
            preset.choLevel = apvts.getRawParameterValue("CHO_LEVEL")->load();
            preset.delTime = apvts.getRawParameterValue("DEL_TIME")->load();
            preset.delFb = apvts.getRawParameterValue("DEL_FB")->load();
            preset.delMix = apvts.getRawParameterValue("DEL_MIX")->load();
            preset.eq1 = apvts.getRawParameterValue("EQ1")->load();
            preset.eq2 = apvts.getRawParameterValue("EQ2")->load();
            preset.eq3 = apvts.getRawParameterValue("EQ3")->load();
            preset.eq4 = apvts.getRawParameterValue("EQ4")->load();
            preset.eq5 = apvts.getRawParameterValue("EQ5")->load();
            preset.eq6 = apvts.getRawParameterValue("EQ6")->load();
            preset.irGain = apvts.getRawParameterValue("IR_GAIN")->load();
            audioProcessor.database.updatePreset(preset);
            repaint();
        }
    };

    prevPresetBtn.setButtonText("<");
    nextPresetBtn.setButtonText(">");
    addAndMakeVisible(prevPresetBtn);
    addAndMakeVisible(nextPresetBtn);

    // --- INPUT / OUTPUT ---
    auto setupModernKnob = [this](juce::Slider& s, juce::Label& l, juce::String name) {
        s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        s.setRange(-20.0, 20.0, 0.1);
        s.setValue(0.0);
        s.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 40, 15);
        s.setColour(juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
        s.setLookAndFeel(&neuralLF);
        s.setName("io");
        addAndMakeVisible(s);

        l.setText(name, juce::dontSendNotification);
        l.setJustificationType(juce::Justification::centred);
        l.setColour(juce::Label::textColourId, juce::Colours::white.withAlpha(0.7f));
        l.setFont(juce::Font(juce::FontOptions().withHeight(13.0f).withStyle("Bold")));
        addAndMakeVisible(l);
        };

    setupModernKnob(inputSlider, inputLabel, "INPUT");
    setupModernKnob(outputSlider, outputLabel, "OUTPUT");

    // --- CONFIGURACIÓN DE AMP ---
    auto setupAmpSlider = [this](juce::Slider& s) {
        s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        s.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
        s.setLookAndFeel(&neuralLF);
        addAndMakeVisible(s);
        };

    setupAmpSlider(gainSlider);
    setupAmpSlider(bassSlider);
    setupAmpSlider(midSlider);
    setupAmpSlider(trebleSlider);
    setupAmpSlider(presenceSlider);
    setupAmpSlider(masterSlider);

    // --- 4. GABINETE ---
    irNameLabel.setText("Sin IR cargado", juce::dontSendNotification);
    irNameLabel.setJustificationType(juce::Justification::centred);
    irNameLabel.setColour(juce::Label::textColourId, juce::Colours::white.withAlpha(0.8f));
    irNameLabel.setFont(juce::Font(juce::FontOptions().withHeight(13.0f).withStyle("Bold")));
    addAndMakeVisible(irNameLabel);

    clearIRBtn.onClick = [this] {
        audioProcessor.clearCabinetIR();
        irNameLabel.setText("Sin IR cargado", juce::dontSendNotification);
        };
    addAndMakeVisible(clearIRBtn);

    addAndMakeVisible(loadIRBtn);
    loadIRBtn.onClick = [this] {
        fileChooser = std::make_unique<juce::FileChooser>("Selecciona un IR...",
            juce::File::getSpecialLocation(juce::File::userMusicDirectory),
            "*.wav");

        fileChooser->launchAsync(juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
            [this](const juce::FileChooser& fc) {
                juce::File file = fc.getResult();
                if (file.existsAsFile()) {
                    audioProcessor.loadCabinetIR(file);
                    irNameLabel.setText(file.getFileNameWithoutExtension(), juce::dontSendNotification);
                }
            });
        };

    irGainSlider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    irGainSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 60, 20);
    irGainSlider.setNumDecimalPlacesToDisplay(1);
    irGainSlider.setTextValueSuffix(" dB");
    irGainSlider.setColour(juce::Slider::thumbColourId, juce::Colours::orange);
    irGainSlider.setLookAndFeel(&neuralLF);
    irGainSlider.setName("noNumbers");
    addAndMakeVisible(irGainSlider);

    auto setupFilterSlider = [this](juce::Slider& s, juce::String suffix) {
        s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        s.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 80, 20);
        s.setNumDecimalPlacesToDisplay(0);
        s.setTextValueSuffix(suffix);
        s.setColour(juce::Slider::thumbColourId, juce::Colours::orange);
        s.setLookAndFeel(&neuralLF);
        s.setName("noNumbers");
        addAndMakeVisible(s);
        };

    setupFilterSlider(lowCutSlider, " Hz");
    lowCutSlider.setRange(10.0, 200.0, 1.0);
    lowCutSlider.setValue(10.0);

    setupFilterSlider(highCutSlider, " Hz");
    highCutSlider.setRange(5000.0, 20000.0, 1.0);
    highCutSlider.setValue(20000.0);

    auto setupFXSlider = [this](juce::Slider& s, juce::Colour col)
        {
            s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
            s.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
            s.setNumDecimalPlacesToDisplay(0);
            s.setColour(juce::Slider::thumbColourId, col);
            s.setLookAndFeel(&neuralLF);
            s.setName("pedal");
            addAndMakeVisible(s);
        };


    setupFXSlider(odDrive, juce::Colours::limegreen); setupFXSlider(odTone, juce::Colours::limegreen); setupFXSlider(odLevel, juce::Colours::limegreen);
    setupFXSlider(choRate, juce::Colours::cyan); setupFXSlider(choDepth, juce::Colours::cyan); setupFXSlider(choLevel, juce::Colours::cyan);
    setupFXSlider(delTime, juce::Colours::mediumpurple); setupFXSlider(delFb, juce::Colours::mediumpurple); setupFXSlider(delMix, juce::Colours::mediumpurple);

    // ===== OVERDRIVE LABELS =====
    odDriveLabel.setText("DRIVE", juce::dontSendNotification);
    odToneLabel.setText("TONE", juce::dontSendNotification);
    odLevelLabel.setText("LEVEL", juce::dontSendNotification);

    for (auto* l : { &odDriveLabel, &odToneLabel, &odLevelLabel })
    {
        l->setJustificationType(juce::Justification::centred);
        l->setColour(juce::Label::textColourId, juce::Colours::white);
        addAndMakeVisible(l);
    }

    // ===== CHORUS LABELS =====
    choRateLabel.setText("RATE", juce::dontSendNotification);
    choDepthLabel.setText("DEPTH", juce::dontSendNotification);
    choLevelLabel.setText("LEVEL", juce::dontSendNotification);

    for (auto* l : { &choRateLabel, &choDepthLabel, &choLevelLabel })
    {
        l->setJustificationType(juce::Justification::centred);
        l->setColour(juce::Label::textColourId, juce::Colours::white);
        addAndMakeVisible(l);
    }

    // ===== DELAY LABELS =====
    delTimeLabel.setText("TIME", juce::dontSendNotification);
    delFbLabel.setText("FEEDBACK", juce::dontSendNotification);
    delMixLabel.setText("MIX", juce::dontSendNotification);

    for (auto* l : { &delTimeLabel, &delFbLabel, &delMixLabel })
    {
        l->setJustificationType(juce::Justification::centred);
        l->setColour(juce::Label::textColourId, juce::Colours::white);
        addAndMakeVisible(l);
    }

    auto setupEQSlider = [this](juce::Slider& s) {
        s.setSliderStyle(juce::Slider::LinearVertical);
        s.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 20);
        s.setRange(-12.0, 12.0, 0.1);
        s.setValue(0.0);
        s.setColour(juce::Slider::trackColourId, juce::Colours::white.withAlpha(0.8f));
        s.setColour(juce::Slider::backgroundColourId, juce::Colours::white.withAlpha(0.15f));
        s.setColour(juce::Slider::thumbColourId, juce::Colour(0xFF111111));
        s.setColour(juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
        s.setColour(juce::Slider::textBoxTextColourId, juce::Colours::white);
        addAndMakeVisible(s);
        };

    setupEQSlider(eqBand1); setupEQSlider(eqBand2); setupEQSlider(eqBand3);
    setupEQSlider(eqBand4); setupEQSlider(eqBand5); setupEQSlider(eqBand6);

    auto setupTab = [this](juce::TextButton& b, int tabID, juce::String name)
        {
            b.setButtonText(name);
            b.setRadioGroupId(1);
            b.setClickingTogglesState(true);
            b.setColour(juce::TextButton::textColourOffId, juce::Colours::white.withAlpha(0.6f));
            b.setColour(juce::TextButton::textColourOnId, juce::Colours::white);
            b.setColour(juce::TextButton::buttonColourId, juce::Colour(0xFF1E1E1E));
            b.setColour(juce::TextButton::buttonOnColourId, juce::Colour(0xFF2A2A2A));

            b.setLookAndFeel(&neuralLF);

            b.onClick = [this, tabID]()
                {
                    currentTab = tabID;
                    updateVisibility();
                    resized();
                    repaint();
                };

            addAndMakeVisible(b);
        };

    setupTab(ampTab, 0, "AMPLIFICADOR");
    setupTab(cabTab, 1, "GABINETE");
    setupTab(fxTab, 2, "EFECTOS");
    setupTab(eqTab, 3, "ECUALIZADOR");
    setupTab(presetsTab, 4, "PRESETS DB");


    ampTab.setToggleState(true, juce::dontSendNotification);
    updateVisibility();

    auto& apvts = audioProcessor.apvts;

    gainAtt = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "GAIN", gainSlider);
    bassAtt = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "BASS", bassSlider);
    midAtt = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "MID", midSlider);
    trebleAtt = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "TREBLE", trebleSlider);
    presenceAtt = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "PRESENCE", presenceSlider);
    masterAtt = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "MASTER", masterSlider);
    inputAtt = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "INPUT", inputSlider);
    outputAtt = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "OUTPUT", outputSlider);
    lowCutAtt = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "LOWCUT", lowCutSlider);
    highCutAtt = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "HIGHCUT", highCutSlider);
    odDriveAtt = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "OD_DRIVE", odDrive);
    odToneAtt = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "OD_TONE", odTone);
    odLevelAtt = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "OD_LEVEL", odLevel);
    choRateAtt = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "CHO_RATE", choRate);
    choDepthAtt = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "CHO_DEPTH", choDepth);
    choLevelAtt = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "CHO_LEVEL", choLevel);
    delTimeAtt = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "DEL_TIME", delTime);
    delFbAtt = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "DEL_FB", delFb);
    delMixAtt = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "DEL_MIX", delMix);
    eqBand1Att = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "EQ1", eqBand1);
    eqBand2Att = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "EQ2", eqBand2);
    eqBand3Att = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "EQ3", eqBand3);
    eqBand4Att = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "EQ4", eqBand4);
    eqBand5Att = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "EQ5", eqBand5);
    eqBand6Att = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "EQ6", eqBand6);
    irGainAtt = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(apvts, "IR_GAIN", irGainSlider);
    odEnableAtt = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(apvts, "OD_ENABLE", odFootswitch);
    choEnableAtt = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(apvts, "CHO_ENABLE", choFootswitch);
    delEnableAtt = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(apvts, "DEL_ENABLE", delFootswitch);

    startTimerHz(30);

    setSize(1400, 700);
}

MESABOOGIEINGSOFTAMPAudioProcessorEditor::~MESABOOGIEINGSOFTAMPAudioProcessorEditor()
{
    gainSlider.setLookAndFeel(nullptr);
    bassSlider.setLookAndFeel(nullptr);
    midSlider.setLookAndFeel(nullptr);
    trebleSlider.setLookAndFeel(nullptr);
    presenceSlider.setLookAndFeel(nullptr);
    masterSlider.setLookAndFeel(nullptr);
    inputSlider.setLookAndFeel(nullptr);
    outputSlider.setLookAndFeel(nullptr);
    lowCutSlider.setLookAndFeel(nullptr);
    highCutSlider.setLookAndFeel(nullptr);
    irGainSlider.setLookAndFeel(nullptr);
    odFootswitch.setLookAndFeel(nullptr);
    choFootswitch.setLookAndFeel(nullptr);
    delFootswitch.setLookAndFeel(nullptr);
}

void MESABOOGIEINGSOFTAMPAudioProcessorEditor::updateVisibility()
{
    bool isTuner = tunerBtn.getToggleState();
    bool isAmp = (currentTab == 0 && !isTuner);
    bool isCab = (currentTab == 1 && !isTuner);
    bool isFx = (currentTab == 2 && !isTuner);
    bool isEq = (currentTab == 3 && !isTuner);
    bool isDB = (currentTab == 4 && !isTuner);
    deletePresetBtn.setVisible(isDB);
    updatePresetBtn.setVisible(isDB);

    inputSlider.setVisible(isAmp); inputLabel.setVisible(isAmp);
    outputSlider.setVisible(isAmp); outputLabel.setVisible(isAmp);
    gainSlider.setVisible(isAmp); bassSlider.setVisible(isAmp); midSlider.setVisible(isAmp);
    trebleSlider.setVisible(isAmp); presenceSlider.setVisible(isAmp); masterSlider.setVisible(isAmp);

    lowCutSlider.setVisible(isCab);
    highCutSlider.setVisible(isCab);
    loadIRBtn.setVisible(isCab);
    clearIRBtn.setVisible(isCab);
    irNameLabel.setVisible(isCab);
    irGainSlider.setVisible(isCab);
    odDrive.setVisible(isFx); odTone.setVisible(isFx); odLevel.setVisible(isFx);
    choRate.setVisible(isFx); choDepth.setVisible(isFx); choLevel.setVisible(isFx);
    delTime.setVisible(isFx); delFb.setVisible(isFx); delMix.setVisible(isFx);
    eqBand1.setVisible(isEq); eqBand2.setVisible(isEq); eqBand3.setVisible(isEq);
    eqBand4.setVisible(isEq); eqBand5.setVisible(isEq); eqBand6.setVisible(isEq);

    odDriveLabel.setVisible(isFx);
    odToneLabel.setVisible(isFx);
    odLevelLabel.setVisible(isFx);

    choRateLabel.setVisible(isFx);
    choDepthLabel.setVisible(isFx);
    choLevelLabel.setVisible(isFx);

    delTimeLabel.setVisible(isFx);
    delFbLabel.setVisible(isFx);
    delMixLabel.setVisible(isFx);

    odFootswitch.setVisible(isFx);
    choFootswitch.setVisible(isFx);
    delFootswitch.setVisible(isFx);

    deletePresetBtn.setVisible(isDB);
    updatePresetBtn.setVisible(isDB);

    repaint();
}

void MESABOOGIEINGSOFTAMPAudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colour(0xFF0A0A0A));

    g.setColour(juce::Colours::black);
    g.fillRect(0, 0, getWidth(), 90);

    g.setColour(juce::Colours::white);
    g.setFont(juce::Font(juce::FontOptions().withHeight(24.0f).withStyle("Bold")));
    g.drawText("NoEraClean AMP", 30, 20, 200, 30, juce::Justification::left);

    if (tunerBtn.getToggleState())
    {
        g.fillAll(juce::Colour(0xFF050505));

        auto area = getLocalBounds().reduced(200, 180).toFloat();

        g.setColour(juce::Colour(0xFF151515));
        g.fillRoundedRectangle(area, 20.0f);

        g.setColour(juce::Colours::orange.withAlpha(0.4f));
        g.drawRoundedRectangle(area, 20.0f, 2.0f);

        g.setColour(juce::Colours::orange);
        g.setFont(juce::Font(juce::FontOptions().withHeight(80.0f).withStyle("Bold")));
        g.drawText(currentNoteName,
            area.toNearestInt(),
            juce::Justification::centred);

        g.setFont(juce::Font(juce::FontOptions().withHeight(20.0f)));
        g.drawText(currentCents,
            area.removeFromBottom(40).toNearestInt(),
            juce::Justification::centred);

        return;
    }
    if (currentTab == 1) // --- PESTAÑA GABINETE ACTUALIZADA ---
    {
        auto areaGabinete = getLocalBounds().reduced(60, 160).withTrimmedTop(-20).toFloat();

        g.setColour(juce::Colour(0xFF151515));
        g.fillRoundedRectangle(areaGabinete, 15.0f);
        g.setColour(juce::Colours::white.withAlpha(0.05f));
        g.drawRoundedRectangle(areaGabinete, 15.0f, 2.0f);

        auto drawSpeaker = [&](juce::Rectangle<float> r) {
            g.setColour(juce::Colours::black.withAlpha(0.6f));
            g.fillEllipse(r);
            g.setColour(juce::Colour(0xFF1A1A1A));
            g.fillEllipse(r.reduced(r.getWidth() * 0.05f));
            g.setColour(juce::Colours::black);
            g.fillEllipse(r.reduced(r.getWidth() * 0.35f));
            g.setColour(juce::Colours::white.withAlpha(0.03f));
            g.drawEllipse(r.reduced(r.getWidth() * 0.1f), 2.0f);
            };

        float speakerSize = 220.0f;
        float yPos = areaGabinete.getY() + 40;
        drawSpeaker(juce::Rectangle<float>(areaGabinete.getX() + 60, yPos, speakerSize, speakerSize));
        drawSpeaker(juce::Rectangle<float>(areaGabinete.getRight() - 60 - speakerSize, yPos, speakerSize, speakerSize));

        g.setColour(juce::Colours::white.withAlpha(0.7f));
        g.setFont(juce::Font(juce::FontOptions().withHeight(14.0f).withStyle("Bold")));
        g.drawText("LOW CUT", lowCutSlider.getX(), lowCutSlider.getY() - 25, lowCutSlider.getWidth(), 20, juce::Justification::centred);
        g.drawText("HIGH CUT", highCutSlider.getX(), highCutSlider.getY() - 25, highCutSlider.getWidth(), 20, juce::Justification::centred);
        g.drawText("IR GAIN", irGainSlider.getX(), irGainSlider.getY() - 25, irGainSlider.getWidth(), 20, juce::Justification::centred);
    }
    else if (currentTab == 2) // ===== EFECTOS =====
    {
        // Fondo completo independiente
        g.fillAll(juce::Colour(0xFF101010));

        juce::ColourGradient bg(
            juce::Colour(0xFF181818),
            getWidth() / 2, 0,
            juce::Colour(0xFF080808),
            getWidth() / 2, getHeight(),
            false);

        g.setGradientFill(bg);
        g.fillRect(getLocalBounds());

        // ===== PEDALES =====

        int pedalWidth = 280;
        int pedalHeight = 380;
        int spacing = 50;

        int totalWidth = pedalWidth * 3 + spacing * 2;
        int startX = (getWidth() - totalWidth) / 2;
        int y = (getHeight() - pedalHeight) / 2;

        juce::Rectangle<int> odArea(startX, y, pedalWidth, pedalHeight);
        juce::Rectangle<int> chArea(startX + pedalWidth + spacing, y, pedalWidth, pedalHeight);
        juce::Rectangle<int> dlArea(startX + (pedalWidth + spacing) * 2, y, pedalWidth, pedalHeight);


        // ===== FUNCION PARA DIBUJAR PEDAL REALISTA =====
        auto drawPedal = [&](juce::Rectangle<int> area,
            juce::Colour color,
            juce::String name,
            juce::Colour ledColor)
            {
                auto r = area.toFloat();

                g.setColour(juce::Colours::black.withAlpha(0.5f));
                g.fillRoundedRectangle(r.translated(4.0f, 6.0f), 12.0f);

                juce::ColourGradient grad(
                    color.brighter(0.4f),
                    r.getCentreX(), r.getY(),
                    color.darker(0.6f),
                    r.getCentreX(), r.getBottom(),
                    false);

                g.setGradientFill(grad);
                g.fillRoundedRectangle(r, 12);

                g.setColour(color.brighter(0.7f));
                g.drawRoundedRectangle(r, 12, 2);

                int screwSize = 10;

                g.setColour(juce::Colours::silver);

                g.fillEllipse(r.getX() + 8, r.getY() + 8, screwSize, screwSize);
                g.fillEllipse(r.getRight() - 18, r.getY() + 8, screwSize, screwSize);
                g.fillEllipse(r.getX() + 8, r.getBottom() - 18, screwSize, screwSize);
                g.fillEllipse(r.getRight() - 18, r.getBottom() - 18, screwSize, screwSize);

                g.setColour(ledColor);
                g.fillEllipse(r.getCentreX() - 7, r.getY() + 16, 14, 14);
                g.setColour(ledColor.brighter(1.0f).withAlpha(0.5f));
                g.drawEllipse(r.getCentreX() - 9, r.getY() + 14, 18, 18, 1.5f);

                // Título un poco más abajo
                g.setColour(juce::Colours::white);
                g.setFont(juce::Font(juce::FontOptions()
                    .withName("Helvetica Neue").withHeight(20.0f).withStyle("Bold")));
                g.drawFittedText(name,
                    juce::Rectangle<int>(area.getX(), area.getBottom() - 95, area.getWidth(), 28),
                    juce::Justification::centred, 1);

                // LED indicador
                g.setColour(ledColor.withAlpha(0.9f));
                g.fillEllipse(r.getCentreX() - 5, r.getY() + 14, 10, 10);
                g.setColour(juce::Colours::white.withAlpha(0.4f));
                g.drawEllipse(r.getCentreX() - 5, r.getY() + 14, 10, 10, 1.0f);

                // Footswitch en la parte de abajo
                float fsX = r.getCentreX() - 28.0f;
                float fsY = r.getBottom() - 72.0f;
                g.setColour(juce::Colours::black.withAlpha(0.7f));
                g.fillEllipse(fsX - 2, fsY + 2, 56, 56);  // sombra
                juce::ColourGradient fsGrad(
                    juce::Colour(0xFF555555), fsX, fsY,
                    juce::Colour(0xFF1A1A1A), fsX, fsY + 56, false);
                g.setGradientFill(fsGrad);
                g.fillEllipse(fsX, fsY, 56, 56);
                g.setColour(juce::Colour(0xFF888888).withAlpha(0.6f));
                g.drawEllipse(fsX, fsY, 56, 56, 2.0f);

            };


        // ===== DIBUJAR PEDALES =====

        drawPedal(odArea, juce::Colour(0xFF228B22), "OVERDRIVE", juce::Colours::lime);

        drawPedal(chArea, juce::Colour(0xFF1E90FF), "CHORUS", juce::Colours::cyan);

        drawPedal(dlArea, juce::Colour(0xFFD2691E), "DELAY", juce::Colours::orange);
    }
    else if (currentTab == 0) // --- SOLO AMPLIFICADOR ---
    {
        auto areaGabinete = juce::Rectangle<float>(0, getHeight() * 0.65f, getWidth(), getHeight() * 0.35f);
        g.setColour(juce::Colour(0xFF0F0F0F));
        g.fillRect(areaGabinete);

        auto rejillaArea = areaGabinete.reduced(50, 0).withTrimmedTop(15);
        auto frame = rejillaArea.expanded(20);

        juce::ColourGradient frameGradient(
            juce::Colour(0xFF101010),
            frame.getTopLeft(),
            juce::Colour(0xFF000000),
            frame.getBottomLeft(),
            false);
        g.setGradientFill(frameGradient);
        g.fillRoundedRectangle(frame.toFloat(), 8.0f);

        // Malla color gris tweed oscuro — más realista
        juce::ColourGradient cabGradient(
            juce::Colour(0xFF2A2520),   // café oscuro cálido
            rejillaArea.getTopLeft(),
            juce::Colour(0xFF151210),   // casi negro
            rejillaArea.getBottomLeft(),
            false);
        g.setGradientFill(cabGradient);
        g.fillRoundedRectangle(rejillaArea.toFloat(), 6.0f);

        // Tejido horizontal (principal)
        for (int y = rejillaArea.getY(); y < rejillaArea.getBottom(); y += 5)
        {
            float alpha = (y % 10 == 0) ? 0.18f : 0.07f;
            g.setColour(juce::Colours::black.withAlpha(alpha));
            g.drawLine((float)rejillaArea.getX(), (float)y,
                (float)rejillaArea.getRight(), (float)y, 1.2f);
        }

        // Tejido vertical (secundario, más fino)
        for (int x = rejillaArea.getX(); x < rejillaArea.getRight(); x += 5)
        {
            g.setColour(juce::Colours::black.withAlpha(0.08f));
            g.drawLine((float)x, (float)rejillaArea.getY(),
                (float)x, (float)rejillaArea.getBottom(), 0.8f);
        }

        // Reflejo superior sutil para dar profundidad
        juce::ColourGradient meshSheen(
            juce::Colours::white.withAlpha(0.04f), rejillaArea.getCentreX(), (float)rejillaArea.getY(),
            juce::Colours::transparentBlack, rejillaArea.getCentreX(), (float)rejillaArea.getY() + 60,
            false);
        g.setGradientFill(meshSheen);
        g.fillRoundedRectangle(rejillaArea.toFloat(), 6.0f);

        g.setColour(juce::Colours::silver.withAlpha(0.6f));
        g.setFont(juce::Font(juce::FontOptions().withName("Impact").withHeight(40.0f)));

        // Placa CAB estilo metal enroscado
        float cabPlateW = 140.0f, cabPlateH = 32.0f;
        float cabPlateX = rejillaArea.getCentreX() - cabPlateW / 2.0f;
        float cabPlateY = (float)rejillaArea.getY() + 20.0f;
        juce::Rectangle<float> cabPlate(cabPlateX, cabPlateY, cabPlateW, cabPlateH);

        juce::ColourGradient cabPlateGrad(
            juce::Colour(0xFF606060), cabPlateX, cabPlateY,
            juce::Colour(0xFF282828), cabPlateX, cabPlateY + cabPlateH, false);
        g.setGradientFill(cabPlateGrad);
        g.fillRoundedRectangle(cabPlate, 4.0f);
        g.setColour(juce::Colour(0xFF888888).withAlpha(0.7f));
        g.drawRoundedRectangle(cabPlate, 4.0f, 1.0f);

        // Tornillos
        for (auto sx : { cabPlateX + 7.0f, cabPlateX + cabPlateW - 14.0f }) {
            g.setColour(juce::Colour(0xFF555555));
            g.fillEllipse(sx, cabPlateY + 10.0f, 8.0f, 8.0f);
            g.setColour(juce::Colour(0xFF333333));
            g.drawLine(sx + 1.5f, cabPlateY + 14.0f, sx + 6.5f, cabPlateY + 14.0f, 1.0f);
        }

        g.setColour(juce::Colour(0xFFDDDDDD));
        g.setFont(juce::Font(juce::FontOptions().withName("Arial").withHeight(16.0f).withStyle("Bold")));
        g.drawText("CAB", cabPlate, juce::Justification::centred);

        if (currentTab == 2)
        {
            auto drawPedal = [&](juce::Rectangle<int> area, juce::String name, juce::Colour colour)
                {
                    g.setColour(colour.withAlpha(1.0f));
                    g.fillRoundedRectangle(area.toFloat(), 12);

                    g.setColour(juce::Colours::black);
                    g.drawRoundedRectangle(area.toFloat(), 10, 2);

                    g.setColour(juce::Colours::white);
                    g.setFont(16);
                    g.drawText(name, area.getX(), area.getY() + 10, area.getWidth(), 20, juce::Justification::centred);
                };

            int pedalWidth = 280;
            int pedalHeight = 380;
            int spacing = 50;

            int totalWidth = pedalWidth * 3 + spacing * 2;
            int startX = (getWidth() - totalWidth) / 2;
            int y = getHeight() * 0.35f;

            drawPedal({ startX, y, pedalWidth, pedalHeight }, "OVERDRIVE", juce::Colours::darkgreen);
            drawPedal({ startX + pedalWidth + spacing, y, pedalWidth, pedalHeight }, "CHORUS", juce::Colours::darkblue);
            drawPedal({ startX + (pedalWidth + spacing) * 2, y, pedalWidth, pedalHeight }, "DELAY", juce::Colours::darkred);
        }

        int headW = getWidth() * 0.75f;
        int headH = 280;
        int headY = (getHeight() * 0.65f) - headH + 5;
        auto areaMueble = juce::Rectangle<float>((getWidth() - headW) / 2.0f, (float)headY, (float)headW, (float)headH);

        g.setColour(juce::Colours::black.withAlpha(0.5f));
        g.fillRoundedRectangle(areaMueble.translated(0, 5), 12.0f);

        g.setColour(juce::Colour(0xFF111111));
        g.fillRoundedRectangle(areaMueble, 12.0f);
        g.setColour(juce::Colour(0xFF333333).withAlpha(0.5f));
        g.drawRoundedRectangle(areaMueble, 12.0f, 2.0f);

        auto panelArea = areaMueble.reduced(25, 35);
        if (currentTab == 0) {

            juce::ColourGradient panelGrad(
                juce::Colour(0xFF1A1A1A), panelArea.getX(), panelArea.getY(),
                juce::Colour(0xFF050505), panelArea.getX(), panelArea.getBottom(), false);
            panelGrad.addColour(0.45, juce::Colour(0xFF161616));
            panelGrad.addColour(0.55, juce::Colour(0xFF080808));
            g.setGradientFill(panelGrad);
            g.fillRoundedRectangle(panelArea, 8.0f);

            // Borde metálico brillante
            g.setColour(juce::Colour(0xFF888888).withAlpha(0.5f));
            g.drawRoundedRectangle(panelArea, 8.0f, 1.2f);

            // Líneas horizontales tipo brushed metal
            for (float ly = panelArea.getY(); ly < panelArea.getBottom(); ly += 3.0f) {
                g.setColour(juce::Colours::white.withAlpha(0.015f));
                g.drawLine(panelArea.getX(), ly, panelArea.getRight(), ly, 1.0f);
            }

            // Placa superior con nombre — tipo placa enroscada
            float plateW = 260.0f, plateH = 36.0f;
            float plateX = panelArea.getCentreX() - plateW / 2.0f;
            float plateY = panelArea.getY() + 10.0f;
            juce::Rectangle<float> namePlate(plateX, plateY, plateW, plateH);

            juce::ColourGradient plateGrad(
                juce::Colour(0xFF555555), plateX, plateY,
                juce::Colour(0xFF222222), plateX, plateY + plateH, false);
            g.setGradientFill(plateGrad);
            g.fillRoundedRectangle(namePlate, 4.0f);
            g.setColour(juce::Colour(0xFFAAAAAA).withAlpha(0.6f));
            g.drawRoundedRectangle(namePlate, 4.0f, 1.0f);

            // Tornillos en la placa
            for (auto screwX : { plateX + 8.0f, plateX + plateW - 14.0f }) {
                g.setColour(juce::Colour(0xFF666666));
                g.fillEllipse(screwX, plateY + 12.0f, 10.0f, 10.0f);
                g.setColour(juce::Colour(0xFF333333));
                g.drawLine(screwX + 2, plateY + 17.0f, screwX + 8, plateY + 17.0f, 1.0f);
            }

            // Nombre sobre la placa
            g.setColour(juce::Colour(0xFFCCCCCC));
            g.setFont(juce::Font(juce::FontOptions().withName("Arial").withHeight(18.0f).withStyle("Bold")));
            g.drawText("NoEraClean", namePlate, juce::Justification::centred);

            g.setColour(juce::Colours::white.withAlpha(0.8f)); // <--- LÍNEA CORREGIDA
            g.setFont(juce::Font(juce::FontOptions().withName("Helvetica").withHeight(11.0f).withStyle("Bold")));
            int startX = (int)panelArea.getX() + 110;
            int knobW = ((int)panelArea.getWidth() - 220) / 6;
            juce::StringArray labels = { "GAIN", "BASS", "MID", "TREBLE", "PRESENCE", "MASTER" };
            for (int i = 0; i < 6; ++i) {
                g.drawText(labels[i], startX + (knobW * i), (int)panelArea.getBottom() - 32, knobW, 15, juce::Justification::centred);
            }
        }
    }

    else if (currentTab == 3) // ===== ECUALIZADOR =====
    {
        g.fillAll(juce::Colour(0xFF0B0B0B));

        auto eqArea = getLocalBounds().reduced(100, 140).toFloat();

        // ===== PANEL PRINCIPAL =====
        g.setColour(juce::Colour(0xFF1A1A1A));
        g.fillRoundedRectangle(eqArea, 20.0f);

        g.setColour(juce::Colours::orange.withAlpha(0.4f));
        g.drawRoundedRectangle(eqArea, 20.0f, 2.0f);

        // ===== dB GRID =====
        g.setColour(juce::Colours::orange.withAlpha(0.15f));

        auto gridArea = eqArea;
        gridArea.removeFromTop(80);
        gridArea.removeFromBottom(60);

        float centerY = gridArea.getCentreY();

        // Línea 0 dB (más fuerte)
        g.setColour(juce::Colours::orange.withAlpha(0.4f));
        g.drawLine(gridArea.getX(), centerY,
            gridArea.getRight(), centerY, 2.0f);

        // Líneas adicionales
        g.setColour(juce::Colours::orange.withAlpha(0.15f));

        float step = gridArea.getHeight() / 4.0f;

        for (int i = 1; i <= 2; ++i)
        {
            g.drawLine(gridArea.getX(),
                centerY - step * i,
                gridArea.getRight(),
                centerY - step * i,
                1.0f);

            g.drawLine(gridArea.getX(),
                centerY + step * i,
                gridArea.getRight(),
                centerY + step * i,
                1.0f);
        }

        // ===== dB LABELS =====
        g.setFont(juce::Font(juce::FontOptions().withHeight(14.0f)));
        g.setColour(juce::Colours::orange.withAlpha(0.6f));

        juce::String labels[] = { "+12db", "+6db", "0", "-6db", "-12db" };

        for (int i = 0; i < 5; ++i)
        {
            float y = gridArea.getY() + (gridArea.getHeight() / 4.0f) * i;

            g.drawText(labels[i],
                (int)(gridArea.getX()) - 50,
                (int)(y - 10.0f),
                40,
                20,
                juce::Justification::centredRight);
        }

        // ===== TITULO =====
        g.setColour(juce::Colours::orange);
        g.setFont(juce::Font(juce::FontOptions().withHeight(26.0f).withStyle("Bold")));
        g.drawText("ECUALIZADOR 6 BANDAS",
            eqArea.removeFromTop(60).toNearestInt(),
            juce::Justification::centred);



        auto graphArea = eqArea.reduced(40, 20);

        // ===== FRECUENCIAS =====
        g.setColour(juce::Colours::white.withAlpha(0.8f));
        g.setFont(juce::Font(14.0f));

        juce::String freqs[6] = { "100 Hz", "200 Hz", "400 Hz", "800 Hz", "1.6 kHz", "3.2 kHz" };

        float bandWidth = graphArea.getWidth() / 6.0f;

        for (int i = 0; i < 6; ++i)
        {
            float x = graphArea.getX() + bandWidth * i;

            juce::Rectangle<float> textArea(x,
                graphArea.getBottom() - 20,
                bandWidth,
                20);

            g.drawText(freqs[i],
                textArea.toNearestInt(),
                juce::Justification::centred);
        }
    }

    else if (currentTab == 4) // ===== TABLA DE PRESETS =====
    {
        g.fillAll(juce::Colour(0xFF0A0A0A));

        // Título
        g.setColour(juce::Colours::orange);
        g.setFont(juce::Font(juce::FontOptions().withHeight(22.0f).withStyle("Bold")));
        g.drawText("BASE DE DATOS - PRESETS GUARDADOS",
        0, 130, getWidth(), 30, juce::Justification::centred);

        auto presets = audioProcessor.database.getAllPresets();

        // Encabezados de tabla
        int tableY = 170;
        int rowH = 28;
        int col0 = 20, w0 = 35;   // ID
        int col1 = 58, w1 = 100;  // Nombre
        int col2 = 161, w2 = 45;   // Gain
        int col3 = 209, w3 = 45;   // Bass
        int col4 = 257, w4 = 45;   // Mid
        int col5 = 305, w5 = 45;   // Treble
        int col6 = 353, w6 = 45;   // Pres
        int col7 = 401, w7 = 45;   // Master
        int col8 = 449, w8 = 45;   // OD Drv
        int col9 = 497, w9 = 45;   // OD Tone
        int col10 = 545, w10 = 45;   // OD Lvl
        int col11 = 593, w11 = 45;   // Cho Rate
        int col12 = 641, w12 = 45;   // Cho Dep
        int col13 = 689, w13 = 45;   // Cho Lvl
        int col14 = 737, w14 = 45;   // Del Time
        int col15 = 785, w15 = 45;   // Del FB
        int col16 = 833, w16 = 45;   // Del Mix
        int col17 = 881, w17 = 35;   // EQ1
        int col18 = 919, w18 = 35;   // EQ2
        int col19 = 957, w19 = 35;   // EQ3
        int col20 = 995, w20 = 35;   // EQ4
        int col21 = 1033, w21 = 35;   // EQ5
        int col22 = 1071, w22 = 35;   // EQ6
        int col23 = 1109, w23 = 55;  // IR Gain  ← ancho reducido para dar espacio
        int col24 = 1164, w24 = 140;  // Fecha

        // Fondo encabezado
        g.setColour(juce::Colour(0xFF222222));
        g.fillRect(col0, tableY, getWidth() - col0 - 20, rowH);

        g.setColour(juce::Colours::orange);
        g.setFont(juce::Font(juce::FontOptions().withHeight(12.0f).withStyle("Bold")));

        g.drawText("ID", col0, tableY, w0, rowH, juce::Justification::centred);
        g.drawText("NOMBRE", col1, tableY, w1, rowH, juce::Justification::centredLeft);
        g.drawText("GAIN", col2, tableY, w2, rowH, juce::Justification::centred);
        g.drawText("BASS", col3, tableY, w3, rowH, juce::Justification::centred);
        g.drawText("MID", col4, tableY, w4, rowH, juce::Justification::centred);
        g.drawText("TREBLE", col5, tableY, w5, rowH, juce::Justification::centred);
        g.drawText("PRES", col6, tableY, w6, rowH, juce::Justification::centred);
        g.drawText("MASTER", col7, tableY, w7, rowH, juce::Justification::centred);
        g.drawText("OD DRV", col8, tableY, w8, rowH, juce::Justification::centred);
        g.drawText("OD TONE", col9, tableY, w9, rowH, juce::Justification::centred);
        g.drawText("OD LVL", col10, tableY, w10, rowH, juce::Justification::centred);
        g.drawText("CHO RT", col11, tableY, w11, rowH, juce::Justification::centred);
        g.drawText("CHO DP", col12, tableY, w12, rowH, juce::Justification::centred);
        g.drawText("CHO LV", col13, tableY, w13, rowH, juce::Justification::centred);
        g.drawText("DEL TM", col14, tableY, w14, rowH, juce::Justification::centred);
        g.drawText("DEL FB", col15, tableY, w15, rowH, juce::Justification::centred);
        g.drawText("DEL MX", col16, tableY, w16, rowH, juce::Justification::centred);
        g.drawText("EQ1", col17, tableY, w17, rowH, juce::Justification::centred);
        g.drawText("EQ2", col18, tableY, w18, rowH, juce::Justification::centred);
        g.drawText("EQ3", col19, tableY, w19, rowH, juce::Justification::centred);
        g.drawText("EQ4", col20, tableY, w20, rowH, juce::Justification::centred);
        g.drawText("EQ5", col21, tableY, w21, rowH, juce::Justification::centred);
        g.drawText("EQ6", col22, tableY, w22, rowH, juce::Justification::centred);
        g.drawText("IR GAIN", col23, tableY, w23, rowH, juce::Justification::centred);
        g.drawText("FECHA", col24, tableY, w24, rowH, juce::Justification::centredLeft);

        // Filas
        g.setFont(juce::Font(juce::FontOptions().withHeight(11.5f)));

        for (int i = 0; i < (int)presets.size(); ++i)
        {
            auto& row = presets[i];
            int y = tableY + rowH + (i * rowH);

            // Fondo alternado
            g.setColour(i % 2 == 0
                ? juce::Colour(0xFF141414)
                : juce::Colour(0xFF1A1A1A));
            g.fillRect(col0, y, getWidth() - col0 - 20, rowH);

            g.setColour(juce::Colours::white.withAlpha(0.85f));
            g.drawText(juce::String(row.id), col0, y, w0, rowH, juce::Justification::centred);
            g.drawText(row.nombre, col1, y, w1, rowH, juce::Justification::centredLeft);
            g.drawText(juce::String(row.gain, 1), col2, y, w2, rowH, juce::Justification::centred);
            g.drawText(juce::String(row.bass, 1), col3, y, w3, rowH, juce::Justification::centred);
            g.drawText(juce::String(row.mid, 1), col4, y, w4, rowH, juce::Justification::centred);
            g.drawText(juce::String(row.treble, 1), col5, y, w5, rowH, juce::Justification::centred);
            g.drawText(juce::String(row.presence, 1), col6, y, w6, rowH, juce::Justification::centred);
            g.drawText(juce::String(row.master, 1), col7, y, w7, rowH, juce::Justification::centred);
            g.drawText(juce::String(row.odDrive, 2), col8, y, w8, rowH, juce::Justification::centred);
            g.drawText(juce::String(row.odTone, 2), col9, y, w9, rowH, juce::Justification::centred);
            g.drawText(juce::String(row.odLevel, 2), col10, y, w10, rowH, juce::Justification::centred);
            g.drawText(juce::String(row.choRate, 2), col11, y, w11, rowH, juce::Justification::centred);
            g.drawText(juce::String(row.choDepth, 2), col12, y, w12, rowH, juce::Justification::centred);
            g.drawText(juce::String(row.choLevel, 2), col13, y, w13, rowH, juce::Justification::centred);
            g.drawText(juce::String(row.delTime, 2), col14, y, w14, rowH, juce::Justification::centred);
            g.drawText(juce::String(row.delFb, 2), col15, y, w15, rowH, juce::Justification::centred);
            g.drawText(juce::String(row.delMix, 2), col16, y, w16, rowH, juce::Justification::centred);
            g.drawText(juce::String(row.eq1, 1), col17, y, w17, rowH, juce::Justification::centred);
            g.drawText(juce::String(row.eq2, 1), col18, y, w18, rowH, juce::Justification::centred);
            g.drawText(juce::String(row.eq3, 1), col19, y, w19, rowH, juce::Justification::centred);
            g.drawText(juce::String(row.eq4, 1), col20, y, w20, rowH, juce::Justification::centred);
            g.drawText(juce::String(row.eq5, 1), col21, y, w21, rowH, juce::Justification::centred);
            g.drawText(juce::String(row.eq6, 1), col22, y, w22, rowH, juce::Justification::centred);
            g.drawText(juce::String(row.irGain, 1), col23, y, w23, rowH, juce::Justification::centred);
            g.drawText(row.fecha, col24, y, w24, rowH, juce::Justification::centredLeft);
            // Línea separadora
            g.setColour(juce::Colours::white.withAlpha(0.05f));
            g.drawLine((float)col0, (float)(y + rowH),
                (float)(getWidth() - 20), (float)(y + rowH), 1.0f);
        }

        if (presets.empty())
        {
            g.setColour(juce::Colours::grey);
            g.setFont(16.0f);
            g.drawText("No hay presets guardados.",
            0, tableY + 60, getWidth(), 30, juce::Justification::centred);
        }

        // Botones BORRAR y ACTUALIZAR
        g.setColour(juce::Colours::red.withAlpha(0.7f));
        g.fillRoundedRectangle(deletePresetBtn.getBounds().toFloat(), 5.0f);
        g.setColour(juce::Colours::orange.withAlpha(0.7f));
        g.fillRoundedRectangle(updatePresetBtn.getBounds().toFloat(), 5.0f);
        }

}

void MESABOOGIEINGSOFTAMPAudioProcessorEditor::timerCallback()
{
    if (!tunerBtn.getToggleState()) return;

    float freq = audioProcessor.getDetectedFrequency();
    if (freq > 20.0f && freq < 2000.0f)
    {
        float pitchMidi = 69.0f + 12.0f * std::log2(freq / 440.0f);
        int midiNote = juce::roundToInt(pitchMidi);
        float cents = (pitchMidi - midiNote) * 100.0f;

        static const juce::StringArray noteNames = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
        currentNoteName = noteNames[midiNote % 12];

        if (std::abs(cents) < 5.0f)
            currentCents = "EN TONO";
        else
            currentCents = juce::String(cents > 0 ? "+" : "") + juce::String(cents, 1) + " cents";
    }
    else
    {
        currentNoteName = "-";
        currentCents = "";
    }
    repaint();
}

void MESABOOGIEINGSOFTAMPAudioProcessorEditor::resized()
{
    auto area = getLocalBounds();
    auto headerArea = area.removeFromTop(80);
    tunerBtn.setBounds(230, 25, 80, 30);

    auto presetArea = headerArea.removeFromRight(450).reduced(20, 25);
    savePresetBtn.setBounds(presetArea.removeFromRight(60));
    nextPresetBtn.setBounds(presetArea.removeFromRight(30));
    presetMenu.setBounds(presetArea.removeFromRight(180).reduced(5, 0));
    prevPresetBtn.setBounds(presetArea.removeFromRight(30));

    auto tabsArea = area.removeFromTop(40);
    int tabW = tabsArea.getWidth() / 5;
    ampTab.setBounds(tabsArea.removeFromLeft(tabW).reduced(15, 5));
    cabTab.setBounds(tabsArea.removeFromLeft(tabW).reduced(15, 5));
    fxTab.setBounds(tabsArea.removeFromLeft(tabW).reduced(15, 5));
    eqTab.setBounds(tabsArea.removeFromLeft(tabW).reduced(15, 5));
    presetsTab.setBounds(tabsArea.removeFromLeft(tabW).reduced(15, 5));

    if (currentTab == 1) // --- GABINETE LAYOUT ---
    {
        auto areaTotal = getLocalBounds();
        int cX = getWidth() / 2;
        int knobY = areaTotal.getBottom() - 240; // zona perillas
        int btnY = knobY + 130;                 // zona botones (justo debajo)
        int labelY = knobY + 170;                 // zona label

        int knobSize = 100;

        // Tres perillas con 40px de separación entre sí
        lowCutSlider.setBounds(cX - 190, knobY, knobSize, knobSize + 20);
        irGainSlider.setBounds(cX - 50, knobY, knobSize, knobSize + 20);
        highCutSlider.setBounds(cX + 90, knobY, knobSize, knobSize + 20);

        // Botones debajo de las perillas, sin solaparse
        loadIRBtn.setBounds(cX - 165, btnY, 150, 32);
        clearIRBtn.setBounds(cX + 5, btnY, 110, 32);

        // Label del archivo cargado
        irNameLabel.setBounds(cX - 165, labelY, 280, 20);
    }

    else if (currentTab == 2) // ===== EFECTOS TAB =====
    {
        int pedalWidth = 280;
        int pedalHeight = 380;
        int spacing = 50;

        int totalWidth = pedalWidth * 3 + spacing * 2;
        int startX = (getWidth() - totalWidth) / 2;
        int y = (getHeight() - pedalHeight) / 2;

        // ================= OVERDRIVE =================
        juce::Rectangle<int> odArea(startX, y, pedalWidth, pedalHeight);

        // OVERDRIVE — knobs arriba
        odDrive.setBounds(odArea.getX() + 25, odArea.getY() + 40, 90, 90);
        odLevel.setBounds(odArea.getX() + 165, odArea.getY() + 40, 90, 90);
        odTone.setBounds(odArea.getX() + 95, odArea.getY() + 130, 90, 90);

        odDriveLabel.setBounds(odDrive.getX(), odDrive.getBottom() + 2, 90, 18);
        odLevelLabel.setBounds(odLevel.getX(), odLevel.getBottom() + 2, 90, 18);
        odToneLabel.setBounds(odTone.getX(), odTone.getBottom() + 2, 90, 18);
        
        // ================= CHORUS =================
        juce::Rectangle<int> choArea(startX + pedalWidth + spacing, y, pedalWidth, pedalHeight);

        choRate.setBounds(choArea.getX() + 25, choArea.getY() + 40, 90, 90);
        choDepth.setBounds(choArea.getX() + 165, choArea.getY() + 40, 90, 90);
        choLevel.setBounds(choArea.getX() + 95, choArea.getY() + 130, 90, 90);

        choRateLabel.setBounds(choRate.getX(), choRate.getBottom() + 2, 90, 18);
        choDepthLabel.setBounds(choDepth.getX(), choDepth.getBottom() + 2, 90, 18);
        choLevelLabel.setBounds(choLevel.getX(), choLevel.getBottom() + 2, 90, 18);

        // ================= DELAY =================
        juce::Rectangle<int> delArea(startX + (pedalWidth + spacing) * 2, y, pedalWidth, pedalHeight);

        delTime.setBounds(delArea.getX() + 25, delArea.getY() + 40, 90, 90);
        delFb.setBounds(delArea.getX() + 165, delArea.getY() + 40, 90, 90);
        delMix.setBounds(delArea.getX() + 95, delArea.getY() + 130, 90, 90);

        delTimeLabel.setBounds(delTime.getX(), delTime.getBottom() + 2, 90, 18);
        delFbLabel.setBounds(delFb.getX(), delFb.getBottom() + 2, 90, 18);
        delMixLabel.setBounds(delMix.getX(), delMix.getBottom() + 2, 90, 18);

        int fsSize = 64;
        odFootswitch.setBounds(odArea.getX() + pedalWidth / 2 - fsSize / 2, odArea.getBottom() - 75, fsSize, fsSize);
        choFootswitch.setBounds(choArea.getX() + pedalWidth / 2 - fsSize / 2, choArea.getBottom() - 75, fsSize, fsSize);
        delFootswitch.setBounds(delArea.getX() + pedalWidth / 2 - fsSize / 2, delArea.getBottom() - 75, fsSize, fsSize);

    }

    else if (currentTab == 3) // ===== EQ TAB =====
    {
        auto eqArea = getLocalBounds().reduced(100, 140);

        auto sliderArea = eqArea;
        sliderArea.removeFromTop(80);     // espacio título
        sliderArea.removeFromBottom(60);  // espacio frecuencias

        int bandWidth = sliderArea.getWidth() / 6;

        eqBand1.setBounds(sliderArea.getX() + bandWidth * 0, sliderArea.getY(), bandWidth, sliderArea.getHeight());
        eqBand2.setBounds(sliderArea.getX() + bandWidth * 1, sliderArea.getY(), bandWidth, sliderArea.getHeight());
        eqBand3.setBounds(sliderArea.getX() + bandWidth * 2, sliderArea.getY(), bandWidth, sliderArea.getHeight());
        eqBand4.setBounds(sliderArea.getX() + bandWidth * 3, sliderArea.getY(), bandWidth, sliderArea.getHeight());
        eqBand5.setBounds(sliderArea.getX() + bandWidth * 4, sliderArea.getY(), bandWidth, sliderArea.getHeight());
        eqBand6.setBounds(sliderArea.getX() + bandWidth * 5, sliderArea.getY(), bandWidth, sliderArea.getHeight());
    }

    else if (currentTab == 4)
    {
        deletePresetBtn.setBounds(getWidth() - 220, getHeight() - 50, 90, 30);
        updatePresetBtn.setBounds(getWidth() - 120, getHeight() - 50, 100, 30);
        deletePresetBtn.setVisible(true);
        updatePresetBtn.setVisible(true);
    }

    else
    {
        // Restaurar botón para presets original
        savePresetBtn.setButtonText("SAVE");
        savePresetBtn.setColour(juce::TextButton::buttonColourId, juce::Colours::transparentBlack);
        savePresetBtn.setColour(juce::TextButton::textColourOffId, juce::Colours::white);

        int headW = getWidth() * 0.75f;
        int headH = 280;
        int headY = (getHeight() * 0.65f) - headH + 5;
        auto areaMueble = juce::Rectangle<int>((getWidth() - headW) / 2, headY, headW, headH);
        auto panelArea = areaMueble.reduced(25, 35);

        int ioY = 140;
        inputSlider.setBounds(30, ioY, 70, 90);
        inputLabel.setBounds(30, ioY - 18, 70, 20);
        outputSlider.setBounds(getWidth() - 110, ioY, 70, 90);
        outputLabel.setBounds(getWidth() - 110, ioY - 18, 70, 20);

        int startX = panelArea.getX() + 110;
        int knobW = (panelArea.getWidth() - 220) / 6;
        int knobY = panelArea.getBottom() - 130;

        gainSlider.setBounds(startX + (knobW * 0), knobY, knobW, 100);
        bassSlider.setBounds(startX + (knobW * 1), knobY, knobW, 100);
        midSlider.setBounds(startX + (knobW * 2), knobY, knobW, 100);
        trebleSlider.setBounds(startX + (knobW * 3), knobY, knobW, 100);
        presenceSlider.setBounds(startX + (knobW * 4), knobY, knobW, 100);
        masterSlider.setBounds(startX + (knobW * 5), knobY, knobW, 100);

        auto fxRow = panelArea.reduced(20);
        int fw = fxRow.getWidth() / 3;
        odDrive.setBounds(fxRow.getX(), fxRow.getY(), fw, 80);
        choRate.setBounds(fxRow.getX() + fw, fxRow.getY(), fw, 80);
        delTime.setBounds(fxRow.getX() + fw * 2, fxRow.getY(), fw, 80);
    }
}